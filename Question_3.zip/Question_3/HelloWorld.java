import java.util.Scanner;
public class HelloWorld{

     public static void main(String []args){
        Scanner s = new Scanner(System.in);
        
        System.out.println("Pick a Number, any number");
     
       
       	int value = s.nextInt();
        
        int [] Coins = {1,2,3};
        
        System.out.println(change(value, Coins ));
        
        s.close();
     }
     
     
     public static int change(int number, int [] arr) {
        
        int value = 0;
        
        if (number == 0 ) {
            return 1;
        }
        
        if (number < 0) {
            return 0;
        }
        
        int i = 0;
        
        while (arr.length != i ) {
            value += change(number-arr[i], arr);
            i++;
        }
        
        return value;
        
     }
}